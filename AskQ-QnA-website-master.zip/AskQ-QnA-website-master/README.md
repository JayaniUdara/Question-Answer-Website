# AskQ-QnA-website
https://askq24x7.000webhostapp.com/

## Introduction

  The project has been developed as a **Question and Answer platform**. Our mission is to share and grow the knowledge about the **Jaffna University**.

## User features

- Can register an account.
- Can log in.
- Can stay logged in using local storage.
- Can log out.
- Can update profile info and upload profile image.
- Can view saved posts.
- Can add a question.
- Can comment on questions

## Application features

- Sensitive data such as passwords is encrypted before adding to the database.
- Fully functional MySql database with restrictions and validation.

## Technologies

### Languages
- JavaScript
- HTML
- CSS

### Databases
- MySql

### Development Software
- Vs Code
